from controller import Robot, GPS, InertialUnit
import math

def clamp_angle(angle):
    """將角度包覆到 [-pi, pi] 區間，避免角度跳躍"""
    return (angle + math.pi) % (2 * math.pi) - math.pi

def goto_point(robot, gps, imu, wheels, x_goal, y_goal, speed=0.4, goal_threshold=0.15, K_omega=2.0):
    WHEEL_RADIUS = 0.0478
    BOT_L = 0.228
    BOT_W = 0.158
    r, L, W = WHEEL_RADIUS, BOT_L, BOT_W
    timestep = int(robot.getBasicTimeStep())
    max_vels = [w.getMaxVelocity() for w in wheels]
    reverse = [False, True, True, False]  # wheel6/wheel7 取 ExteriorWheel, 需反向
    while True:
        ret = robot.step(timestep)
        if ret == -1:
            print("robot.step 被中止，goto_point 結束")
            return
        pos = gps.getValues()
        x, y = pos[0], pos[1]
        dx, dy = x_goal - x, y_goal - y
        dist = math.hypot(dx, dy)
        print(f"[goto_point] 目前({x:.2f},{y:.2f}) → 目標({x_goal:.2f},{y_goal:.2f}), 剩餘距離:{dist:.3f}")
        if dist < goal_threshold:
            break
        yaw = imu.getRollPitchYaw()[2]
        theta_goal = math.atan2(dy, dx)
        heading_error = clamp_angle(theta_goal - yaw)
        omega = K_omega * heading_error
        vx_world = dx / (dist + 1e-9) * speed
        vy_world = dy / (dist + 1e-9) * speed
        v_x = math.cos(yaw) * vx_world + math.sin(yaw) * vy_world
        v_y = -math.sin(yaw) * vx_world + math.cos(yaw) * vy_world
        w1 = (1/r) * (v_x - v_y - (L+W)*omega)
        w2 = (1/r) * (v_x + v_y + (L+W)*omega)
        w3 = (1/r) * (v_x + v_y - (L+W)*omega)
        w4 = (1/r) * (v_x - v_y + (L+W)*omega)
        wheel_speeds = [w1, w2, w3, w4]
        for i in range(4):
            v = max(-max_vels[i], min(max_vels[i], wheel_speeds[i]))
            if reverse[i]:
                v = -v
            wheels[i].setVelocity(v)
    for w in wheels:
        w.setVelocity(0.0)
    print(f"[goto_point] 抵達 ({x_goal},{y_goal})")

def turn_heading_to_point(robot, imu, wheels, x_now, y_now, x_target, y_target, tolerance=8.0, max_steps=200):
    WHEEL_RADIUS = 0.0478
    BOT_L = 0.228
    BOT_W = 0.158
    r, L, W = WHEEL_RADIUS, BOT_L, BOT_W
    timestep = int(robot.getBasicTimeStep())
    max_vels = [w.getMaxVelocity() for w in wheels]
    theta_goal = math.atan2(y_target - y_now, x_target - x_now)
    steps = 0
    while True:
        if steps > max_steps:
            print("[turn_heading] timeout，強制跳出")
            break
        steps += 1
        ret = robot.step(timestep)
        if ret == -1:
            print("robot.step 被中止，turn_heading_to_point 結束")
            return
        yaw = imu.getRollPitchYaw()[2]
        error = clamp_angle(theta_goal - yaw)
        print(f"[turn_heading] 現在朝向 {math.degrees(yaw):.2f}° 目標 {math.degrees(theta_goal):.2f}° 誤差 {math.degrees(error):.2f}°")
        if abs(math.degrees(error)) < tolerance:
            break
        K = 1.0
        omega = K * error
        v_x = v_y = 0
        w1 = (1/r) * (v_x - v_y - (L+W)*omega)
        w2 = (1/r) * (v_x + v_y + (L+W)*omega)
        w3 = (1/r) * (v_x + v_y - (L+W)*omega)
        w4 = (1/r) * (v_x - v_y + (L+W)*omega)
        wheel_speeds = [w1, w2, w3, w4]
        for i in range(4):
            v = max(-max_vels[i], min(max_vels[i], wheel_speeds[i]))
            wheels[i].setVelocity(-v)
    for w in wheels:
        w.setVelocity(0.0)
    print(f"[turn_heading] 已朝向 ({x_target},{y_target})")

def passive_wait(robot, sec):
    start_time = robot.getTime()
    while robot.getTime() - start_time < sec:
        if robot.step(int(robot.getBasicTimeStep())) == -1:
            break

robot = Robot()
timestep = int(robot.getBasicTimeStep())

gps = robot.getDevice("gps")
imu = robot.getDevice("inertial unit")
gps.enable(timestep)
imu.enable(timestep)
wheel_names = ["wheel5", "wheel6", "wheel7", "wheel8"]
wheels = [robot.getDevice(name) for name in wheel_names]
for w in wheels:
    w.setPosition(float('inf'))

for _ in range(10):
    robot.step(timestep)

pos = gps.getValues()
x0, y0 = pos[0], pos[1]
radius = 7.0

current_angle = math.atan2(y0, x0)
if current_angle < 0:
    current_angle += 2 * math.pi

angles = [((current_angle + (2*math.pi)*i/12) % (2*math.pi)) for i in range(12)]
waypoints = [(radius * math.cos(a), radius * math.sin(a)) for a in angles]
min_idx = min(range(12), key=lambda i: math.hypot(waypoints[i][0] - x0, waypoints[i][1] - y0))
ordered_waypoints = waypoints[min_idx:] + waypoints[:min_idx] + [(x0, y0)]

for idx, (wx, wy) in enumerate(ordered_waypoints):
    print(f"\n=== 準備前往第 {idx+1} 個點: ({wx:.2f}, {wy:.2f}) ===")
    goto_point(robot, gps, imu, wheels, wx, wy)
    pos = gps.getValues()
    x_now, y_now = pos[0], pos[1]
    turn_heading_to_point(robot, imu, wheels, x_now, y_now, 0.0, 0.0)
    print(f"已抵達第 {idx+1} 個點: ({wx:.2f}, {wy:.2f})，車頭已指向 (0, 0)")
    passive_wait(robot, 1.0)

print("\n已完成圍繞半徑7m圓周12點繞行並回到起點，任務結束。")